// stdafx.h : Includedatei f�r Standardsystem-Includedateien
// oder h�ufig verwendete projektspezifische Includedateien,
// die nur in unregelm��igen Abst�nden ge�ndert werden.
//

#pragma once

#include "targetver.h"

#define RAUF 10000
#define RECHTS 10001
#define RUNTER 10002
#define LINKS 10003

#define ADD 10004

const int SPEED = 0;
const int DELAY = 1;

const int SPEED_PLAYER = 1;
const int SPEED_ENEMY = 3;
const int SPEED_STONE = 2;

const int MAX_X = 80;
const int MAX_Y = 25;
	  //int MAX_STONE = 40;
const int MAX_EMEMY = 8;

#define EMPTY 32
#define SAND 177 //219
#define ROCK 167 //206 //188
#define WALL 58 //197 //177
#define STONE 184
#define PLAYER 1
#define ENEMY 2
#define DIAMOND 3


#include <cstdio>
#include <conio.h>
#include <tchar.h>
#include <windows.h>
#include <WinCon.h>
#include <iostream>
#include <stdlib.h>
#include <vector>


enum color
{
    black,
    darkblue,
    darkgreen,
    darkcyan,
    darkred,
    darkpurple,
    darkgray,
    darkwhite,
    gray,
    blue,
    green,
    cyan,
    red,
    purple,
    yellow,
    white
};


// TODO: Hier auf zus�tzliche Header, die das Programm erfordert, verweisen.
