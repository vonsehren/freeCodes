#ifndef GAME_H
#define GAME_H

#include "stdafx.h"
#include "level.h"
#include "player.h"
#include "stone.h"

class Game
{
public:
	Game(void);

	void init(Player* _p_ptr);

	void move(int _v);
	//void gravity(void);

	void update(void);
	void debug(void);

	Player* player_ptr;
	
	Level level;
	Stone stone[200];

private:
	int MAX_STONE;
};

#endif