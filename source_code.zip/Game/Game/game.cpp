
#include "stdafx.h"
#include "game.h"
#include <iostream>

Game::Game(void)
{
	MAX_STONE = 0;
}

void Game::debug(void)
{
	level.drawMap();
}

void Game::init(Player* _p_ptr)
{
	player_ptr = _p_ptr;

	level.load();
	level.drawMap();

	int i=0;
	for (int y=0; y<MAX_Y; y++)
		for (int x=0; x<MAX_X; x++)
		{
			if (level.map[x][y][0] == STONE)
			{
				stone[i].setX(x);
				stone[i].setY(y);
				level.map[x][y][1] = i;
				i++;
				std::cout << x << " " << y;
			}
		}

	MAX_STONE = i;
	//std::cout << i;
	_p_ptr->init(&level);
}

void Game::update(void)
{
	//std::cout << MAX_STONE;
	for (int i=0; i<MAX_STONE; i++)
	{
		stone[i].gravity(&level);
	}
}

