#include "stdafx.h"
#include "level.h"
#include <time.h>

Level::Level(void)
{

}

void Level::draw(int _x, int _y, int _value)
{
	point.X = _x;
	point.Y = _y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), point);
			
			switch(_value)
				{
				case ROCK:
					{
						setColor(black, 3);
					} break;
				case SAND:
					{
						//setColor(black, 6);
						setColor(black, 8);
					} break;
				case WALL:
					{
						setColor(8, black);
					} break;
				case EMPTY:
					{
						setColor(0, black);
					} break;
				case STONE:
					{
						setColor(black, 11); //15
					} break;
				case PLAYER:
					{
						setColor(black, 14);
					} break;
				}
	std::cout << (char)_value;
}

void Level::load()
{
	srand(time(NULL));

	// Spielfeld f�llen
	for (int y=0; y<MAX_Y; y++)
		for (int x=0; x<MAX_X; x++)
		{
			if ( ((x > 1 && y > 2) && (x < MAX_X-2 && y < MAX_Y-2)) )
			{
				int value = rand() %9 + 1;

				if (value < 7) map[x][y][0] = SAND;
				else if (value < 9) map[x][y][0] = WALL;
				else
				{
					map[x][y][0] = SAND;
					
				}
			}
			else map[x][y][0] = ROCK;
	
		}
	// Mitte, Leeres K�stchen
	for (int y=9; y<17; y++)
		for (int x=16; x<34; x++)
		{
			map[x][y][0] = EMPTY;
			map[x+30][y][0] = EMPTY;
		}
	// Player stelle ist mit sand umrandet
	map[3][3][0] = SAND;
	map[3][4][0] = SAND;
	map[2][4][0] = SAND;

	map[5][5][0] = STONE;
	map[5][6][0] = STONE;
	map[6][5][0] = STONE;
}

void Level::drawMap(void)
{
	for (int y=0; y<MAX_Y; y++)
		for (int x=0; x<MAX_X; x++)
		{
				point.X = x;
				point.Y = y;
				SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), point);
			
				switch(map[x][y][0])
				{
				case ROCK:
					{
						setColor(black, 3);
					} break;
				case SAND:
					{
						setColor(black, 8);
					} break;
				case WALL:
					{
						setColor(8, black);
					} break;
				case EMPTY:
					{
						setColor(0, black);
					} break;
				case STONE:
					{
						setColor(black, 11); //15
					} break;
				case PLAYER:
					{
						setColor(black, 14);
					} break;
				}
				std::cout << (char)map[x][y][0];
		}


	// Damit Bild nicht um eins runter r�ckt
	point.X = 0;
	point.Y = 0;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), point);

}

void Level::setColor(int colorBack, int colorFore)
{
    int back = 0;
    if (colorBack & 1) back |= BACKGROUND_BLUE;
    if (colorBack & 2) back |= BACKGROUND_GREEN;
    if (colorBack & 4) back |= BACKGROUND_RED;
    if (colorBack & 8) back |= BACKGROUND_INTENSITY;

    int fore = 0;
    if (colorFore & 1) fore |= FOREGROUND_BLUE;
    if (colorFore & 2) fore |= FOREGROUND_GREEN;
    if (colorFore & 4) fore |= FOREGROUND_RED;
    if (colorFore & 8) fore |= FOREGROUND_INTENSITY;

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), back | fore);
}